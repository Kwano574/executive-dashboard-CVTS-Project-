//browser side(frontend) js to allow fetching from backend js api routes
fetch("http://localhost:3001/api/jobs/status")
    .then(response => response.json())
    .then(data => {

        const labels = Object.keys(data);
        const values = Object.values(data);

        new Chart(
            document.getElementById("statusChart"),
            {
                type: "pie",

                data: {
                    labels: labels,

                    datasets: [{
                        data: values
                    }]
                }
            }
        );

    })
    .catch(error => {
        console.error(
            "Status chart failed:",
            error
        );
    });
