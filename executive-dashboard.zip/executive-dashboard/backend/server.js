//backend js used to create api routes and return json
const express = require("express");//bringing express into this file 
const cors = require("cors");//helps frontend ports communicate with backend ports
require("dotenv").config();//allows backedn to authenticate with synchroteam

const app = express();//creating my express web apllication

app.use(cors());
app.use(express.json());

// Read Synchroteam credentials from .env
const username = process.env.SYNCHROTEAM_USERNAME;//means go into .env and find the varaible called username/password
const password = process.env.SYNCHROTEAM_PASSWORD;

// Check that credentials exist
if (!username || !password) {
    console.error("Synchroteam credentials are missing from .env");
    process.exit(1);
}

//creating Basic Auth values from .env
const basicAuth = Buffer
    .from(`${username}:${password}`)
    .toString("base64");


    //simple test route
app.get("/test", (req, res) => {//when someone send a request run the following code
    res.json({

        message: "Executive Dashboard backend is running"
    });
});

// demo job retrieval test
app.get("/api/job", (req, res) => {

    const jobs = [
        {
            num: 1665,
            customer: "CVTS",
            status: "synchronized",
            type: "freshwater"
        }
    ];

    res.json(jobs);
});

//fetiching real jobs from synchroteam
app.get("/api/jobs", async (req, res) => {

    try {

        const response = await fetch(
            "https://ws.synchroteam.com/api/v3/job/list?page=1&pageSize=100",
            {
                headers: {
                    "Authorization": `Basic ${basicAuth}`,
                    "Accept": "application/json"
                }
            }
        );

        if (!response.ok) {
            throw new Error(
                `Synchroteam returned ${response.status}`
            );
        }

        const data = await response.json();

        res.json(data);

    } catch (error) {

        console.error(error);

        res.status(500).json({
            error: "Could not retrieve jobs from Synchroteam"
        });

    }

});

//getting jobs by their status using agrregation
app.get("/api/jobs/status", async (req, res) => {

    try {

        const response = await fetch(
            "https://ws.synchroteam.com/api/v3/job/list?page=1&pageSize=100",
            {
                headers: {
                    "Authorization": `Basic ${basicAuth}`,
                    "Accept": "application/json"
                }
            }
        );

        const result = await response.json();

        const jobs = result.data;

        const statusCounts = {};

        jobs.forEach(job => {

            const status =
                job.status || "unknown";

            statusCounts[status] =
                (statusCounts[status] || 0) + 1;

        });

        res.json(statusCounts);

    } catch (error) {

        res.status(500).json({
            error: "Could not aggregate job statuses"
        });

    }

});

//start server on port 3001
app.listen(3001, () => {//starting server on port 300
    console.log("Server running on http://localhost:3001");
});