from fastapi import FastAPI

#creating FastAPI application
app= FastAPI()

#creating an endpoint that return
@app.get("/")
def home():
    return {"message": "Executive Dashboard backend is running"}
